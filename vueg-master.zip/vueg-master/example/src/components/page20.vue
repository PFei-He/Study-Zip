<template>
    <div>
        <h1>页面2-0</h1>
        <a @click="$router.push('page-2/page2-1')">转到页面2-1</a>
    </div>
</template>
<script>
export default {
    data() {
        return {
            vuegConfig: {
                disable: false
            }
        }
    }
}
</script>
<style scoped>
div {
    text-align: center;
    background-color: pink;
}

h1 {}
</style>
