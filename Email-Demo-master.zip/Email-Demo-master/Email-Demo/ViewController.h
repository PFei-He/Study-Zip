//
//  ViewController.h
//  Email-Demo
//
//  Created by Jennifer A Sipila on 7/21/16.
//  Copyright © 2016 Jennifer A Sipila. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

@interface ViewController : UIViewController <MFMailComposeViewControllerDelegate>


@end

