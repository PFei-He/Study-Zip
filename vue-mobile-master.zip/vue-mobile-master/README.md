# vue-mobile

说明地址：http://www.jianshu.com/p/d7587e81dbd8



