<template lang="html">
  <div class="search">

  </div>
</template>

<script>
export default {
}
</script>

<style lang="stylus" ref="stylesheet/stylus">



</style>
