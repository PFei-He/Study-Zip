export default {
  // countAnother: function (state) {
  //       return state.anotherIncrement
  //   }

}
