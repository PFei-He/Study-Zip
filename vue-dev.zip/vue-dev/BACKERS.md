# Backers

You can join them in supporting  Vue.js development by [pledging on Patreon](https://www.patreon.com/evanyou)! Backers in the same pledge level appear in the order of pledge date.

### $2000

<a href="https://stdlib.com/">
  <img width="600px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/stdlib.png">
</a>

---

### $1000

<a href="https://xiaozhuanlan.com">
  <img width="400px" src="https://raw.githubusercontent.com/vuejs/cn.vuejs.org/master/themes/vue/source/images/xiaozhuanlan.png">
</a>

---

### $500

<a href="https://deepstreamhub.com">
  <img width="260px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/deepstream.png">
</a>
<br><br>
<a href="https://jsfiddle.net/">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/jsfiddle.png">
</a>
<br><br>
<a href="https://laravel.com">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/laravel.png">
</a>
<br><br>
<a href="https://chaitin.cn">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/chaitin.png">
</a>
<br><br>
<a href="https://htmlburger.com/">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/htmlburger.png">
</a>
<br><br>
<a href="https://starter.someline.com/">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/someline.png">
</a>
<br><br>
<a href="http://monterail.com/" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/monterail.png">
</a>
<br><br>
<a href="https://www.2mhost.com/" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/2mhost.png">
</a>
<br><br>
<a href="https://vuejsjob.com/?ref=vuejs" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/vuejobs.png">
</a>
<br><br>
<a href="https://leanpub.com/vuejs2" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/tmvuejs2.png">
</a>
<br><br>
<a href="https://component.io/" target="_blank">
  <img width="260px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/component_io.png">
</a>
<br><br>
<a href="https://www.v2ex.com/t/379389" target="_blank">
  <img width="260px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/v2exer.png">
</a>

---

### Sponsors via [OpenCollective](https://opencollective.com/vuejs#sponsor)

<a href="https://opencollective.com/vuejs/sponsor/0/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/0/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/1/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/1/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/2/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/2/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/3/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/3/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/4/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/4/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/5/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/5/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/6/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/6/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/7/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/7/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/8/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/8/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/9/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/9/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/10/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/10/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/11/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/11/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/12/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/12/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/13/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/13/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/14/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/14/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/15/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/15/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/16/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/16/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/17/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/17/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/18/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/18/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/19/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/19/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/20/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/20/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/21/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/21/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/22/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/22/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/23/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/23/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/24/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/24/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/25/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/25/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/26/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/26/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/27/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/27/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/28/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/28/avatar.svg"></a>
<a href="https://opencollective.com/vuejs/sponsor/29/website" target="_blank"><img src="https://opencollective.com/vuejs/sponsor/29/avatar.svg"></a>

---

### $250

- Matt Mullenweg

---

### $100

<a href="http://tighten.co/">
  <img width="240px" src="http://i.imgur.com/T7fQYLT.png">
</a>
<br><br>
<a href="http://invoicemachine.com/">
  <img width="220px" src="http://assets.invoicemachine.com/images/flat_logo.png">
</a>
<br><br>
<a href="https://alligator.io">
  <img width="240px" src="https://alligator.io/images/alligator-logo.svg">
</a>
<br><br>
<a href="https://monei.net/">
  <img width="200px" src="http://i.imgur.com/JUSjHAi.png">
</a>
<br><br>
<a href="https://www.accelebrate.com/">
  <img width="220px" src="https://www.accelebrate.com/assets/images/accelebrate_logo@2x.png">
</a>
<br><br>
<a href="https://www.waterfall.com">
  <img width="200px" src="https://waterfall.com/waterfall_logo_large.png">
</a>
<br><br>
<a href="https://vuetifyjs.com">
  <img width="80px" src="https://vuetifyjs.com/static/doc-images/logo.svg"> Vuetify
</a>

---

### $50+ via Patreon

- No Divide Studio
- James Kyle
- Blake Newman
- Lee Smith
- Adam Dorsey
- Greg McCarvell
- Yoshiya Hinosawa
- Wasim Khamlichi
- errorrik
- Alex Balashov
- Konstantin Levinski
- Samuel Smith

---

### $10+ via Patreon

- Sylvain Pollet-Villard
- Luca Borghini
- Kazuya Kawaguchi
- Keisuke Kita
- Anirudh Sanjeev
- Guido Bertolino
- Fábio Vedovelli
- Jack Barham
- Stephane Demoote
- Paul R. Dillinger
- Sean Washington
- Alun Davey
- Eduardo Kyvenko
- Thijs de Maa
- Joris Noordermeer
- Niklas Lifors
- An Phan
- Richard Wyke
- Roman Kuba
- Tom Conlon
- Matt Pickle
- Simon East
- Bill Columbia
- Hayden Bickerton
- Henry Zhu
- John Smith
- Benjamin Listwon
- Rainer Morgan
- Brian Jorden
- Christopher Dosin
- Lars Andreas Ness
- Drew Lustro
- Victor Tolbert
- Jon Pokrzyk
- Frank Dungan III
- Lanes.io
- Anders
- Dexter Miguel
- Stephen Michael Hartley
- Wen-Tien Chang
- Ole Støvern
- Valerian Cure
- Dani Ilops
- louisbl
- Yegor Sytnyk
- Guido H.
- Joan Cejudo
- Ian Walter
- Nikola Trifunovic
- Nicolas Mutis Mesa
- Fahed Toumi
- James Brooks
- Kirk Lewis
- Spenser
- Takuya Nishio
- Daniel Diekmeier
- Peter Thaleikis
- Karol Fabjanczuk
- Eduardo
- Lê Chương
- Webber Wang
- Daniel Schmitz
- Bruce Li
- Mohammed
- Sam Wainwright
- TJ Hillard
- Kyle Arrington
- Jason Land
- Miljan Aleksic
- James Ye
- Laurids Duellmann
- Christo Crampton
- Adon Metcalfe
- Paul Straw
- Jake Ingman
- Eduardo Camillo
- Barbara Liau
- Jens Lind
- Yegor Sytnyk
- Benson Wong
- Anthony Tsui
- Karol Fabjanczuk
- Isaac Sant
- Milos Stojanovic
- Matsumoto Takamasa
- Douglas Lowder
- Bess Brooks
- Christian Griffith
- Matt Rockwell
- Jarek Tkaczyk
- Michael Laccetti
- Jonothan Allen
- Andrew Davis
- Jason Rys
- Sean
- Xiaojie Li
- Joakim Bugge
- Lacey Pevey
- David Hess
- Niannian Modisette
- Kim Cuartero
- Luke Sampson
- Dariusz Jastrzębski
- Ivan Sieder
- Jivan Roquet
- Shane
- Stew Heckenberg
- Matt Jones
- Dave Chenell
- Frank Baele
- Jack McDade
- Patrick O'Dacre
- Wietse Wind
- Donny Donny
- Duncan Kenzie
- Mike Margerum
- Michael Richards
- Eduardo Reveles
- Jan Kremlacek
- Guy Gavergun
- Keith Bailey
- Joel Birch
- Bernhard E. Reiter
- Radu Cretu
- Luiz Tanure
- Poamrong Rith
- Chengzhi Yin
- Dan Barrett
- Zoran Knezevic
- Charles Beaumont
- Jonathan Kent
- James Simpson
- Pascal Germain
- Pierre Vanhulst
- Vincent Gabriel
- Kyovo Digaw
- devneko
- Cheng-Wei Chien
- Michael Mazurczak
- Daniel
- Chris Anderson
- Jon Hobbs-Smith
- Chez Tschetter
- Akiho Nagao
- Alexander Karelas
- Asaf Yishai
- Diana Espino
- Alexandre Madurell
- alxs
- Anthony Estebe
- Haim Yulzari
- Blake Campbell
- David McGuigan
- Niklas Wallentin
- Jeremy Tan
- Jim Raden
- Luka Savic
- IMGNRY
- Pascal Germain
- Raphaël Saunier
- Kirk Lewis
- Nicholas Reid
- Tyler
- Yong Jun Thong
- Jonatan Machado
- Tai Shi Ling
- Bryan Gruneberg
- Matthew McMillion
- Keith Mancuso
- Alexander Karelas
- Matias Verdier

## Backers via [OpenCollective](https://opencollective.com/vuejs#backer)

<a href="https://opencollective.com/vuejs#backers" target="_blank"><img src="https://opencollective.com/vuejs/backers.svg?width=890"></a>
