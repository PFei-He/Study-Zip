<template>
    <div>
        引导页1
    </div>
</template>
<script>
	export default{
		data(){
			return {
				vuegConfig:{
					disable:false
				}
			}
		}
	}
</script>
<style scoped>
div {
    background: linear-gradient(to bottom, #c9d6ff, #e2e2e2);
}
</style>
