<template>
	<div>
		引导页3
	</div>
</template>
<script>
	export default{
		data(){
			return {
				vuegConfig:{
					disable:false
				}
			}
		}
	}
</script>
<style scoped>
	div{
		background: linear-gradient(to bottom, #dae2f8, #d6a4a4);
	}
</style>