<template>
    <router-view class="view"></router-view>
</template>
<script>
export default {
    name: 'guide'
}
</script>
<style>
.view {
    min-height: 100%;
    text-align: center;
    line-height: 100px;
    color: rgba(0,0,0,0.5);
}
</style>
