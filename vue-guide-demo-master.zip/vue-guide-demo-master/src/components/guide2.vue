<template>
    <div>
        引导页2
    </div>
</template>
<script>
	export default{
		data(){
			return {
				vuegConfig:{
					disable:false
				}
			}
		}
	}
</script>
<style scoped>
div {
    background: linear-gradient(to bottom, #d9a7c7, #fffcdc);
    ;
}
</style>
