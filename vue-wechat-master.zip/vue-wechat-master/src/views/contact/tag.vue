<template>
    <div class="">
        
    </div>
</template>
<script>
import topHandle from 'topHandle'

export default {
    vuex:{
        getters:{
            backPath:state=>state.back_path,
        }
    },
    data() {
        return {
            
        }
    },
    methods:{
        
    },
    components:{
        topHandle
    }
}
</script>
<style scoped>
    
</style>
