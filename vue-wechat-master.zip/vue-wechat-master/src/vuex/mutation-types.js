export const SET_MENU = 'SET_MENU'
export const SET_MENU_ACTIVE = 'SET_MENU_ACTIVE'
export const BACK_PATH = 'BACK_PATH'

//chat
export const SET_MENU_WECHAT_LIST = 'SET_MENU_WECHAT_LIST'
export const CHAT = 'CHAT'
export const SET_CHAT_COUNT = 'SET_CHAT_COUNT'
export const SET_NEWS_STATE = 'SET_NEWS_STATE'
export const DELETE_NEWS = 'DELETE_NEWS'

//contact
export const PERSON_INFO = 'PERSON_INFO'
export const CONTACT_FRIENDS = 'CONTACT_FRIENDS'
export const FRIEND_ID = 'FRIEND_ID'
