module.exports = [{
    "alpha": "A",
    "list": [{
        "id": 1,
        "name": "杨涛",
        "nickname":"杨涛",
        "remark":"阿涛",
        "wxid": "wxid_yangtao",
        "qq": "00000",
        "email": "00000@qq.com",
        "type": "friends",
        "iconSrc": "//ad-gold-cdn.xitu.io/14999138688354f1720f589d2d33db77f026bb07c8f67.jpg",
        "qrCode": "",
        "signature": "个性签名"
    }]
},{
    "alpha": "B",
    "list": [{
        "id": 12,
        "name": "baijiahei",
        "nickname":"baijiahei",
        "remark":"白加黑",
        "wxid": "wxid_baijiahei",
        "qq": "00000",
        "email": "00000@qq.com",
        "type": "friends",
        "iconSrc": "//ad-gold-cdn.xitu.io/1499914019068553d2c25d0b33b83481795c552e0b47f.jpg",
        "qrCode": "",
        "signature": "个性签名"
    }]
}, {
    "alpha": "X",
    "list": [{
        "id": 11,
        "name":"小明",
        "nickname": "小明",
        "remark":"小明",
        "wxid": "wxid_xiaoming",
        "qq": "00011",
        "email": "00011@qq.com",
        "type": "firends",
        "iconSrc": "//ad-gold-cdn.xitu.io/1499913563353063825fa09e5e83359a90c91417e029e.jpg",
        "qrCode": "",
        "telphone":18812345678,
        "signature": "个性签名",
        "area":["中国","北京","海淀"],
        "selfPhotos":[{imgSrc:""}]
    },{
        "id": 13,
        "nickname": "小亮",
        "name": "小亮",
        "remark":"小亮",
        "wxid": "wxid_xiaoliang",
        "qq": "00011",
        "email": "00011@qq.com",
        "type": "firends",
        "iconSrc": "//ad-gold-cdn.xitu.io/14999140634069b6825290779221783b3b59fbba0addd.jpg",
        "qrCode": "",
        "telphone":18812345678,
        "signature": "个性签名",
        "area":["中国","北京","海淀"],
        "selfPhotos":[{imgSrc:""}]
    }]
}]
