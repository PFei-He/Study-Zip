# Building a Mobile App with Cordova and Vue.js

This code is for the tutorial on building a random word generator using Cordova and Vue.js by [@MichaelViveros](https://github.com/MichaelViveros)

Check out the full tutorial at [coligo](https://coligo.io/building-a-mobile-app-with-cordova-vuejs/)
