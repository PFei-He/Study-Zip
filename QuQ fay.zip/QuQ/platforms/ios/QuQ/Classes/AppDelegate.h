//
//  AppDelegate.h
//  QuQ
//
//  Created by Fay on 2017/8/4.
//  Copyright © 2017年 Fay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder

@property (strong, nonatomic) UIWindow *window;


@end
