//
//  QuQMainViewController.h
//  QuQ
//
//  Created by Fay on 2017/8/4.
//
//

#import <UIKit/UIKit.h>

@interface QuQMainViewController : UIViewController

@end
