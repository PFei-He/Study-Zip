/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
    },

    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
        
        var string = '';
        if (isMobile.Android()) {
            string = 'Hello, Android!';
        } else if (isMobile.iOS()) {
            string = 'Hello, iOS!';
        }
        
        // 按钮一
        var btn = document.getElementById('btn1');
        btn.onclick = function() {
            cordova.exec(function() {}, function() {}, 'Adapter', 'adapter_dismiss_web', [string]);
            Adapter.log();
        }
        
        // 按钮二
        var btn = document.getElementById('btn2');
        btn.onclick = function() {
            $.ajax({
                url: "http://www.weather.com.cn/data/sk/101010100.html",
                success: function(result) {
                    console.log('[ QuQ ][ NETWORK ] Request success.');
                    console.log('[ QuQ ][ INFO ] ' + result);
                },
                error: function(xhr, status, error) {
                    console.log('[ QuQ ][ NETWORK ] Request failure.');
                    console.log('[ QuQ ][ INFO ] ' + xhr);
                    console.log('[ QuQ ][ INFO ] ' + status);
                    console.log('[ QuQ ][ INFO ] ' + error);
                }
            });
        }
    }
};

app.initialize();

var isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i);
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    }
};

function adapter_dismiss() {
    if (isMobile.Android()) {
        console.log('QuQ: Web dismiss!');
    } else if (isMobile.iOS()) {
        console.log('Web dismiss!');
    }
}
