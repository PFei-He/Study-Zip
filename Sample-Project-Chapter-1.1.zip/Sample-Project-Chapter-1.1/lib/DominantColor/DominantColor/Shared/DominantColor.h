//
//  DominantColor.h
//  DominantColor
//
//  Created by Indragie on 12/22/14.
//  Copyright (c) 2014 Indragie Karunaratne. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DominantColor.
FOUNDATION_EXPORT double DominantColorVersionNumber;

//! Project version string for DominantColor.
FOUNDATION_EXPORT const unsigned char DominantColorVersionString[];

#import "ColorSpaceConversion.h"
#import "RandomNumbers.h"
