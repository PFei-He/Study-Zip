# The Moody Sample Project

This is sample code for chapter 1.1 of the objc.io [Core Data book](https://www.objc.io/books/core-data/).

## Building & Running

You need [Xcode 8](https://developer.apple.com/xcode/) or later to build this project.

