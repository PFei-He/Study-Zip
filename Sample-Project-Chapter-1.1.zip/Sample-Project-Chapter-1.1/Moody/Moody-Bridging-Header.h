//
//  Moody-BridgingHeader.h
//  Moody
//
//  Created by Florian Kugler on 14-11-2016.
//  Copyright © 2016 objc.io. All rights reserved.
//

#ifndef Moody_BridgingHeader_h
#define Moody_BridgingHeader_h

#import "DominantColor.h"

#endif /* Moody_BridgingHeader_h */
