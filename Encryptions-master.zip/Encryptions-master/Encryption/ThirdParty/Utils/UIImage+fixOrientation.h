//
//  UIImage+fixOrientation.h
//  STATION
//
//  Created by Hope on 12-5-1.
//  Copyright (c) 2012年  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (fixOrientation)

+(UIImage *)fixOrientation:(UIImage *)aImage;

@end
